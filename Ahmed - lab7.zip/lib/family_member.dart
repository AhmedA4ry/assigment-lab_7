import 'package:flutter/material.dart';
import 'package:audioplayers/audioplayers.dart';

class family_mem extends StatelessWidget {
  final player = AudioPlayer();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color(0xff5a3a1f),
        title: Text(
          'Family Members ',
        ),
      ),
      body: ListView(
        children: [
          Container(
            height: 100,
            color: Color(0xffeba32f),
            child: Row(children: [
              Container(
                child: Image.asset('assets/image/grandfather.png'),
                color: Color(0xfff0e0c8),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 10),
                child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text("Ojisan",
                          style: TextStyle(
                            fontSize: 20,
                          )),
                      Text("GrandFather",
                          style: TextStyle(
                            fontSize: 20,
                          )),
                    ]),
              ),
              Spacer(
                flex: 1,
              ),
              Padding(
                padding: const EdgeInsets.only(right: 15),
                child: InkWell(
                    onTap: () {
                      player.play(AssetSource('sounds/grandfather.wav'));
                    },
                    child: Icon(Icons.play_arrow, size: 30)),
              ),
            ]),
          ),
          Container(
            height: 100,
            color: Color(0xffeba32f),
            child: Row(children: [
              Container(
                child: Image.asset('assets/image/grandmother.png'),
                color: Color(0xfff0e0c8),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 10),
                child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text("O bachan",
                          style: TextStyle(
                            fontSize: 20,
                          )),
                      Text("GrandMother",
                          style: TextStyle(
                            fontSize: 20,
                          )),
                    ]),
              ),
              Spacer(
                flex: 1,
              ),
              Padding(
                padding: const EdgeInsets.only(right: 15),
                child: InkWell(
                    onTap: () {
                      player.play(AssetSource('sounds/grandmother.wav'));
                    },
                    child: Icon(Icons.play_arrow, size: 30)),
              ),
            ]),
          ),
          Container(
            height: 100,
            color: Color(0xffeba32f),
            child: Row(children: [
              Container(
                child: Image.asset('assets/image/father.png'),
                color: Color(0xfff0e0c8),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 10),
                child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text("Chichioya",
                          style: TextStyle(
                            fontSize: 20,
                          )),
                      Text("Father",
                          style: TextStyle(
                            fontSize: 20,
                          )),
                    ]),
              ),
              Spacer(
                flex: 1,
              ),
              Padding(
                padding: const EdgeInsets.only(right: 15),
                child: InkWell(
                    onTap: () {
                      player.play(AssetSource('sounds/father.wav'));
                    },
                    child: Icon(Icons.play_arrow, size: 30)),
              ),
            ]),
          ),
          Container(
            height: 100,
            color: Color(0xffeba32f),
            child: Row(children: [
              Container(
                child: Image.asset('assets/image/mother.png'),
                color: Color(0xfff0e0c8),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 10),
                child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text("Hahaoya",
                          style: TextStyle(
                            fontSize: 20,
                          )),
                      Text("Mother",
                          style: TextStyle(
                            fontSize: 20,
                          )),
                    ]),
              ),
              Spacer(
                flex: 1,
              ),
              Padding(
                padding: const EdgeInsets.only(right: 15),
                child: InkWell(
                    onTap: () {
                      player.play(AssetSource('sounds/mother.wav'));
                    },
                    child: Icon(Icons.play_arrow, size: 30)),
              ),
            ]),
          ),
          Container(
            height: 100,
            color: Color(0xffeba32f),
            child: Row(children: [
              Container(
                child: Image.asset('assets/image/son.png'),
                color: Color(0xfff0e0c8),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 10),
                child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text("Musuko",
                          style: TextStyle(
                            fontSize: 20,
                          )),
                      Text("Son",
                          style: TextStyle(
                            fontSize: 20,
                          )),
                    ]),
              ),
              Spacer(
                flex: 1,
              ),
              Padding(
                padding: const EdgeInsets.only(right: 15),
                child: InkWell(
                    onTap: () {
                      player.play(AssetSource('sounds/son.wav'));
                    },
                    child: Icon(Icons.play_arrow, size: 30)),
              ),
            ]),
          ),
          Container(
            height: 100,
            color: Color(0xffeba32f),
            child: Row(children: [
              Container(
                child: Image.asset('assets/image/daughter.png'),
                color: Color(0xfff0e0c8),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 10),
                child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text("Musume",
                          style: TextStyle(
                            fontSize: 20,
                          )),
                      Text("Daughter",
                          style: TextStyle(
                            fontSize: 20,
                          )),
                    ]),
              ),
              Spacer(
                flex: 1,
              ),
              Padding(
                padding: const EdgeInsets.only(right: 15),
                child: InkWell(
                    onTap: () {
                      player.play(AssetSource('sounds/daughter.wav'));
                    },
                    child: Icon(Icons.play_arrow, size: 30)),
              ),
            ]),
          ),
        ],
      ),
    );
  }
}
